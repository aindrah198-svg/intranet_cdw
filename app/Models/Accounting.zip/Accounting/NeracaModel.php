<?php
namespace App\Models\Accounting;

use CodeIgniter\Model;
use App\Models\CoaModel;

class NeracaModel extends Model
{
    protected $table = 'buku_besar';
    protected $primaryKey = 'id';
    protected $useAutoIncrement = true;
    protected $returnType = 'array';
    protected $useSoftDeletes = false;
    protected $protectFields = true;
    
    protected $useTimestamps = false;

    /**
     * Get saldo akun berdasarkan periode
     */
    public function getSaldoAkun($coaId, $tanggalMulai, $tanggalSelesai)
    {
        // Ambil saldo awal (sebelum periode)
        $saldoAwal = $this->getSaldoAwal($coaId, $tanggalMulai);
        
        // Ambil mutasi selama periode
        $mutasi = $this->getMutasiPeriode($coaId, $tanggalMulai, $tanggalSelesai);
        
        $debit = $mutasi['debit'] ?? 0;
        $kredit = $mutasi['kredit'] ?? 0;
        
        return [
            'saldo_awal' => $saldoAwal,
            'debit' => $debit,
            'kredit' => $kredit,
            'saldo_akhir' => $saldoAwal + $debit - $kredit
        ];
    }

    /**
     * Get saldo awal akun (sebelum periode)
     */
    public function getSaldoAwal($coaId, $tanggalMulai)
    {
        $builder = $this->db->table('buku_besar')
            ->select('saldo_akhir')
            ->where('coa_id', $coaId)
            ->where('tanggal <', $tanggalMulai)
            ->orderBy('tanggal', 'DESC')
            ->orderBy('id', 'DESC')
            ->limit(1);
        
        $result = $builder->get()->getRow();
        
        return $result->saldo_akhir ?? 0;
    }

    /**
     * Get mutasi periode
     */
    public function getMutasiPeriode($coaId, $tanggalMulai, $tanggalSelesai)
    {
        $builder = $this->db->table('buku_besar')
            ->select('SUM(debit) as total_debit, SUM(kredit) as total_kredit')
            ->where('coa_id', $coaId)
            ->where('tanggal >=', $tanggalMulai)
            ->where('tanggal <=', $tanggalSelesai);
        
        $result = $builder->get()->getRow();
        
        return [
            'debit' => $result->total_debit ?? 0,
            'kredit' => $result->total_kredit ?? 0
        ];
    }

    /**
     * Get neraca untuk periode tertentu
     */
    public function getNeraca($tanggalPeriode)
    {
        $coaModel = new CoaModel();
        
        // Ambil semua akun aset
        $akunAset = $coaModel->where('tipe_akun', 'Aset')
                              ->where('is_header', 0)
                              ->where('is_active', 1)
                              ->orderBy('kode_akun', 'ASC')
                              ->findAll();
        
        // Ambil semua akun kewajiban
        $akunKewajiban = $coaModel->where('tipe_akun', 'Kewajiban')
                                   ->where('is_header', 0)
                                   ->where('is_active', 1)
                                   ->orderBy('kode_akun', 'ASC')
                                   ->findAll();
        
        // Ambil semua akun ekuitas
        $akunEkuitas = $coaModel->where('tipe_akun', 'Ekuitas')
                                 ->where('is_header', 0)
                                 ->where('is_active', 1)
                                 ->orderBy('kode_akun', 'ASC')
                                 ->findAll();
        
        // Hitung saldo masing-masing akun
        $aset = [];
        $totalAset = 0;
        
        foreach ($akunAset as $akun) {
            $saldo = $this->getSaldoAkun($akun['id'], '1900-01-01', $tanggalPeriode);
            $nilai = $saldo['saldo_akhir'];
            
            $aset[] = [
                'kode_akun' => $akun['kode_akun'],
                'nama_akun' => $akun['nama_akun'],
                'saldo' => $nilai,
                'saldo_normal' => $akun['saldo_normal']
            ];
            $totalAset += $nilai;
        }
        
        // Hitung saldo kewajiban
        $kewajiban = [];
        $totalKewajiban = 0;
        
        foreach ($akunKewajiban as $akun) {
            $saldo = $this->getSaldoAkun($akun['id'], '1900-01-01', $tanggalPeriode);
            $nilai = $saldo['saldo_akhir'];
            
            $kewajiban[] = [
                'kode_akun' => $akun['kode_akun'],
                'nama_akun' => $akun['nama_akun'],
                'saldo' => $nilai,
                'saldo_normal' => $akun['saldo_normal']
            ];
            $totalKewajiban += $nilai;
        }
        
        // Hitung saldo ekuitas
        $ekuitas = [];
        $totalEkuitas = 0;
        
        foreach ($akunEkuitas as $akun) {
            $saldo = $this->getSaldoAkun($akun['id'], '1900-01-01', $tanggalPeriode);
            $nilai = $saldo['saldo_akhir'];
            
            $ekuitas[] = [
                'kode_akun' => $akun['kode_akun'],
                'nama_akun' => $akun['nama_akun'],
                'saldo' => $nilai,
                'saldo_normal' => $akun['saldo_normal']
            ];
            $totalEkuitas += $nilai;
        }
        
        // Hitung laba tahun berjalan
        $labaRugiModel = new LabaRugiModel();
        $tanggalMulaiTahun = date('Y-01-01', strtotime($tanggalPeriode));
        $labaRugi = $labaRugiModel->getLabaRugi($tanggalMulaiTahun, $tanggalPeriode);
        $labaTahunBerjalan = $labaRugi['laba_rugi'];
        
        // Tambahkan laba ke ekuitas
        $totalEkuitas += $labaTahunBerjalan;
        
        return [
            'tanggal' => $tanggalPeriode,
            'aset' => $aset,
            'total_aset' => $totalAset,
            'kewajiban' => $kewajiban,
            'total_kewajiban' => $totalKewajiban,
            'ekuitas' => $ekuitas,
            'laba_tahun_berjalan' => $labaTahunBerjalan,
            'total_ekuitas' => $totalEkuitas,
            'total_pasiva' => $totalKewajiban + $totalEkuitas,
            'selisih' => $totalAset - ($totalKewajiban + $totalEkuitas)
        ];
    }

    /**
     * Get neraca komparatif (perbandingan dengan periode sebelumnya)
     */
    public function getNeracaKomparatif($tanggalPeriode)
    {
        // Hitung neraca periode ini
        $neracaSaatIni = $this->getNeraca($tanggalPeriode);
        
        // Hitung neraca periode sebelumnya (tahun lalu)
        $tanggalLalu = date('Y-m-d', strtotime($tanggalPeriode . ' -1 year'));
        $neracaSebelum = $this->getNeraca($tanggalLalu);
        
        // Hitung perubahan
        $perubahanAset = $neracaSaatIni['total_aset'] - $neracaSebelum['total_aset'];
        $perubahanKewajiban = $neracaSaatIni['total_kewajiban'] - $neracaSebelum['total_kewajiban'];
        $perubahanEkuitas = $neracaSaatIni['total_ekuitas'] - $neracaSebelum['total_ekuitas'];
        
        return [
            'periode_saat_ini' => [
                'tanggal' => $tanggalPeriode,
                'total_aset' => $neracaSaatIni['total_aset'],
                'total_kewajiban' => $neracaSaatIni['total_kewajiban'],
                'total_ekuitas' => $neracaSaatIni['total_ekuitas']
            ],
            'periode_sebelum' => [
                'tanggal' => $tanggalLalu,
                'total_aset' => $neracaSebelum['total_aset'],
                'total_kewajiban' => $neracaSebelum['total_kewajiban'],
                'total_ekuitas' => $neracaSebelum['total_ekuitas']
            ],
            'perubahan' => [
                'aset' => $perubahanAset,
                'aset_persen' => $neracaSebelum['total_aset'] > 0 
                    ? ($perubahanAset / $neracaSebelum['total_aset']) * 100 
                    : 0,
                'kewajiban' => $perubahanKewajiban,
                'kewajiban_persen' => $neracaSebelum['total_kewajiban'] > 0 
                    ? ($perubahanKewajiban / $neracaSebelum['total_kewajiban']) * 100 
                    : 0,
                'ekuitas' => $perubahanEkuitas,
                'ekuitas_persen' => $neracaSebelum['total_ekuitas'] > 0 
                    ? ($perubahanEkuitas / $neracaSebelum['total_ekuitas']) * 100 
                    : 0
            ]
        ];
    }

    /**
     * Get ringkasan neraca untuk dashboard
     */
    public function getDashboardSummary($tanggalPeriode = null)
    {
        if (!$tanggalPeriode) {
            $tanggalPeriode = date('Y-m-d');
        }
        
        $neraca = $this->getNeraca($tanggalPeriode);
        
        // Hitung rasio likuiditas
        $asetLancar = $this->getTotalAsetLancar($tanggalPeriode);
        $kewajibanLancar = $this->getTotalKewajibanLancar($tanggalPeriode);
        
        $currentRatio = $kewajibanLancar > 0 ? $asetLancar / $kewajibanLancar : 0;
        $quickRatio = $kewajibanLancar > 0 ? ($asetLancar - $this->getTotalPersediaan($tanggalPeriode)) / $kewajibanLancar : 0;
        
        return [
            'total_aset' => $neraca['total_aset'],
            'total_kewajiban' => $neraca['total_kewajiban'],
            'total_ekuitas' => $neraca['total_ekuitas'],
            'aset_lancar' => $asetLancar,
            'kewajiban_lancar' => $kewajibanLancar,
            'current_ratio' => $currentRatio,
            'quick_ratio' => $quickRatio,
            'modal_kerja' => $asetLancar - $kewajibanLancar,
            'der' => $neraca['total_ekuitas'] > 0 
                ? $neraca['total_kewajiban'] / $neraca['total_ekuitas'] 
                : 0
        ];
    }

    /**
     * Get total aset lancar
     */
    private function getTotalAsetLancar($tanggalPeriode)
    {
        $coaModel = new CoaModel();
        
        // Cari akun aset lancar (biasanya kode 1-1xxx)
        $akunAsetLancar = $coaModel->where('kode_akun LIKE', '1-1%')
                                   ->where('is_header', 0)
                                   ->where('is_active', 1)
                                   ->findAll();
        
        $total = 0;
        foreach ($akunAsetLancar as $akun) {
            $saldo = $this->getSaldoAkun($akun['id'], '1900-01-01', $tanggalPeriode);
            $total += $saldo['saldo_akhir'];
        }
        
        return $total;
    }

    /**
     * Get total kewajiban lancar
     */
    private function getTotalKewajibanLancar($tanggalPeriode)
    {
        $coaModel = new CoaModel();
        
        // Cari akun kewajiban lancar (biasanya kode 2-1xxx)
        $akunKewajibanLancar = $coaModel->where('kode_akun LIKE', '2-1%')
                                        ->where('is_header', 0)
                                        ->where('is_active', 1)
                                        ->findAll();
        
        $total = 0;
        foreach ($akunKewajibanLancar as $akun) {
            $saldo = $this->getSaldoAkun($akun['id'], '1900-01-01', $tanggalPeriode);
            $total += $saldo['saldo_akhir'];
        }
        
        return $total;
    }

    /**
     * Get total persediaan
     */
    private function getTotalPersediaan($tanggalPeriode)
    {
        $coaModel = new CoaModel();
        
        // Cari akun persediaan (biasanya kode 1-13xx)
        $akunPersediaan = $coaModel->where('kode_akun LIKE', '1-13%')
                                   ->where('is_header', 0)
                                   ->where('is_active', 1)
                                   ->findAll();
        
        $total = 0;
        foreach ($akunPersediaan as $akun) {
            $saldo = $this->getSaldoAkun($akun['id'], '1900-01-01', $tanggalPeriode);
            $total += $saldo['saldo_akhir'];
        }
        
        return $total;
    }

    /**
     * Export data untuk Excel
     */
    public function getExportData($tanggalPeriode)
    {
        $neraca = $this->getNeraca($tanggalPeriode);
        
        return [
            'tanggal' => $tanggalPeriode,
            'aset' => $neraca['aset'],
            'total_aset' => $neraca['total_aset'],
            'kewajiban' => $neraca['kewajiban'],
            'total_kewajiban' => $neraca['total_kewajiban'],
            'ekuitas' => $neraca['ekuitas'],
            'laba_tahun_berjalan' => $neraca['laba_tahun_berjalan'],
            'total_ekuitas' => $neraca['total_ekuitas'],
            'total_pasiva' => $neraca['total_pasiva']
        ];
    }
}