<?php
namespace App\Models\Accounting;

use CodeIgniter\Model;
use App\Models\Teknisi\SpkInstalasiPengeluaranModel;

class MutasiBankModel extends Model
{
    protected $table = 'mutasi_bank';
    protected $primaryKey = 'id';
    protected $useAutoIncrement = true;
    protected $returnType = 'array';
    protected $useSoftDeletes = false;
    protected $protectFields = true;
    protected $allowedFields = [
        'tanggal',
        'kode_transaksi',
        'tipe',
        'jumlah',
        'keterangan',
        'coa_id_debit',
        'coa_id_kredit',
        'bank_asal',
        'bank_tujuan',
        'no_referensi',
        'lampiran',
        'status',
        'posted_at',
        'jurnal_id',
        'spk_id',
        'pengeluaran_id',
        'created_by'
    ];

    protected $useTimestamps = true;
    protected $dateFormat = 'datetime';
    protected $createdField = 'created_at';
    protected $updatedField = 'updated_at';

    protected $validationRules = [
        'tanggal' => 'required|valid_date',
        'tipe' => 'required|in_list[Debit,Kredit]',
        'jumlah' => 'required|numeric|greater_than[0]',
        'keterangan' => 'required',
        'status' => 'permit_empty|in_list[Draft,Posted,Dibatalkan]'
    ];

    protected $validationMessages = [
        'tanggal' => [
            'required' => 'Tanggal transaksi harus diisi',
            'valid_date' => 'Format tanggal tidak valid'
        ],
        'tipe' => [
            'required' => 'Tipe transaksi (Debit/Kredit) harus dipilih'
        ],
        'jumlah' => [
            'required' => 'Jumlah harus diisi',
            'numeric' => 'Jumlah harus berupa angka',
            'greater_than' => 'Jumlah harus lebih besar dari 0'
        ],
        'keterangan' => [
            'required' => 'Keterangan harus diisi'
        ]
    ];

    protected $skipValidation = false;
    protected $cleanValidationRules = true;

    protected $allowCallbacks = true;
    protected $beforeInsert = ['generateKodeTransaksi', 'setCreatedBy', 'validateCoa'];
    protected $beforeUpdate = ['validateCoa', 'validateStatusChange'];

    /**
     * Generate kode transaksi otomatis
     * Format: MB-YYYYMMDD-XXXX
     */
    protected function generateKodeTransaksi(array $data)
    {
        if (empty($data['data']['kode_transaksi'])) {
            $tanggal = $data['data']['tanggal'] ?? date('Y-m-d');
            $prefix = 'MB-' . date('Ymd', strtotime($tanggal)) . '-';
            
            $lastTransaksi = $this->select('kode_transaksi')
                ->like('kode_transaksi', $prefix, 'after')
                ->orderBy('kode_transaksi', 'DESC')
                ->first();
            
            if ($lastTransaksi) {
                $lastNum = substr($lastTransaksi['kode_transaksi'], strlen($prefix));
                $nextNum = str_pad((int)$lastNum + 1, 4, '0', STR_PAD_LEFT);
            } else {
                $nextNum = '0001';
            }
            
            $data['data']['kode_transaksi'] = $prefix . $nextNum;
        }
        
        return $data;
    }

    /**
     * Validasi COA berdasarkan tipe transaksi
     */
    protected function validateCoa(array $data)
    {
        $tipe = $data['data']['tipe'] ?? null;
        
        if ($tipe === 'Debit') {
            if (empty($data['data']['coa_id_debit'])) {
                throw new \RuntimeException('Untuk transaksi Debit (uang keluar), akun debit harus diisi');
            }
        } 
        elseif ($tipe === 'Kredit') {
            if (empty($data['data']['coa_id_kredit'])) {
                throw new \RuntimeException('Untuk transaksi Kredit (uang masuk), akun kredit harus diisi');
            }
        }
        
        return $data;
    }

    /**
     * Validasi perubahan status
     */
    protected function validateStatusChange(array $data)
    {
        if (isset($data['data']['status'])) {
            $id = $data['id'][0] ?? null;
            
            if ($id) {
                $current = $this->find($id);
                
                if ($data['data']['status'] === 'Posted' && $current['status'] === 'Draft') {
                    if (empty($current['jurnal_id']) && empty($data['data']['jurnal_id'])) {
                        throw new \RuntimeException('Transaksi harus memiliki jurnal_id sebelum diposting');
                    }
                }
                
                if ($data['data']['status'] === 'Dibatalkan' && $current['status'] === 'Posted') {
                    throw new \RuntimeException('Transaksi yang sudah diposting tidak dapat dibatalkan');
                }
            }
        }
        
        return $data;
    }

    protected function setCreatedBy(array $data)
    {
        $data['data']['created_by'] = session()->get('user_id');
        return $data;
    }

    /**
     * Get all mutasi bank with filters and pagination
     * DIPERBAIKI: Saldo akan akurat di semua halaman
     */
    public function getAllWithFilters($filters = [], $perPage = 20, $page = 1)
    {
        $builder = $this->select('mutasi_bank.*, 
            creator.username as creator_name,
            coa_debit.kode_akun as kode_akun_debit,
            coa_debit.nama_akun as nama_akun_debit,
            coa_debit.tipe_akun as tipe_akun_debit,
            coa_kredit.kode_akun as kode_akun_kredit,
            coa_kredit.nama_akun as nama_akun_kredit,
            coa_kredit.tipe_akun as tipe_akun_kredit,
            jurnal.nomor_jurnal,
            spk.nomor_spk,
            spk.judul_pekerjaan')
            ->join('users as creator', 'creator.id = mutasi_bank.created_by', 'left')
            ->join('coa as coa_debit', 'coa_debit.id = mutasi_bank.coa_id_debit', 'left')
            ->join('coa as coa_kredit', 'coa_kredit.id = mutasi_bank.coa_id_kredit', 'left')
            ->join('jurnal', 'jurnal.id = mutasi_bank.jurnal_id', 'left')
            ->join('spk_instalasi as spk', 'spk.id = mutasi_bank.spk_id', 'left');
        
        // Apply filters
        if (!empty($filters['search'])) {
            $search = $filters['search'];
            $builder->groupStart()
                ->like('mutasi_bank.kode_transaksi', $search)
                ->orLike('mutasi_bank.keterangan', $search)
                ->orLike('mutasi_bank.no_referensi', $search)
                ->orLike('coa_debit.nama_akun', $search)
                ->orLike('coa_kredit.nama_akun', $search)
                ->orLike('spk.nomor_spk', $search)
                ->orLike('spk.judul_pekerjaan', $search)
                ->groupEnd();
        }
        
        if (!empty($filters['tanggal_mulai'])) {
            $builder->where('mutasi_bank.tanggal >=', $filters['tanggal_mulai']);
        }
        
        if (!empty($filters['tanggal_selesai'])) {
            $builder->where('mutasi_bank.tanggal <=', $filters['tanggal_selesai']);
        }
        
        if (!empty($filters['tipe'])) {
            $builder->where('mutasi_bank.tipe', $filters['tipe']);
        }
        
        if (!empty($filters['status'])) {
            $builder->where('mutasi_bank.status', $filters['status']);
        }
        
        if (!empty($filters['bank'])) {
            $builder->groupStart()
                ->like('mutasi_bank.bank_asal', $filters['bank'])
                ->orLike('mutasi_bank.bank_tujuan', $filters['bank'])
                ->groupEnd();
        }
        
        if (!empty($filters['coa_bank_id'])) {
            $builder->groupStart()
                ->where('mutasi_bank.coa_id_debit', $filters['coa_bank_id'])
                ->orWhere('mutasi_bank.coa_id_kredit', $filters['coa_bank_id'])
                ->groupEnd();
        }

        if (!empty($filters['spk_id'])) {
            $builder->where('mutasi_bank.spk_id', $filters['spk_id']);
        }
        
        // Urutkan dari yang TERLAMA ke TERBARU untuk perhitungan saldo yang benar
        $builder->orderBy('mutasi_bank.tanggal', 'ASC')
                ->orderBy('mutasi_bank.id', 'ASC');
        
        // Get total for pagination
        $total = $builder->countAllResults(false);
        
        // Get paginated results
        $offset = ($page - 1) * $perPage;
        $mutasi = $builder->limit($perPage, $offset)->findAll();
        
        // Hitung saldo dengan mengambil semua transaksi sebelum halaman ini
        $coaBankId = $filters['coa_bank_id'] ?? null;
        $mutasi = $this->calculateSaldoWithOffset($mutasi, $filters, $offset, $coaBankId);
        
        return [
            'data' => $mutasi,
            'total' => $total,
            'per_page' => $perPage,
            'current_page' => $page,
            'total_pages' => ceil($total / $perPage)
        ];
    }

    /**
     * Hitung saldo berjalan dengan mempertimbangkan offset pagination
     */
    private function calculateSaldoWithOffset($mutasi, $filters, $offset, $coaBankId = null)
    {
        if (empty($mutasi)) {
            return $mutasi;
        }
        
        // Ambil saldo awal sebelum offset (semua transaksi sebelum halaman ini)
        $saldoAwal = $this->getSaldoSebelumOffset($filters, $offset, $coaBankId);
        
        // Hitung saldo kumulatif untuk data di halaman ini
        $saldo = $saldoAwal;
        
        foreach ($mutasi as &$item) {
            if ($item['tipe'] === 'Kredit') {
                $saldo += $item['jumlah'];
            } else {
                $saldo -= $item['jumlah'];
            }
            $item['saldo_berjalan'] = $saldo;
        }
        
        return $mutasi;
    }

    /**
     * Ambil saldo dari semua transaksi sebelum offset tertentu
     */
    private function getSaldoSebelumOffset($filters, $offset, $coaBankId = null)
    {
        $builder = $this->db->table('mutasi_bank')
            ->select("
                SUM(CASE WHEN tipe = 'Kredit' THEN jumlah ELSE 0 END) as total_masuk,
                SUM(CASE WHEN tipe = 'Debit' THEN jumlah ELSE 0 END) as total_keluar
            ")
            ->where('status', 'Posted');
        
        // Apply filters yang sama
        if (!empty($filters['tanggal_mulai'])) {
            $builder->where('tanggal >=', $filters['tanggal_mulai']);
        }
        
        if (!empty($filters['tanggal_selesai'])) {
            $builder->where('tanggal <=', $filters['tanggal_selesai']);
        }
        
        if (!empty($filters['tipe'])) {
            $builder->where('tipe', $filters['tipe']);
        }
        
        if (!empty($filters['status'])) {
            $builder->where('status', $filters['status']);
        }
        
        if (!empty($filters['bank'])) {
            $builder->groupStart()
                ->like('bank_asal', $filters['bank'])
                ->orLike('bank_tujuan', $filters['bank'])
                ->groupEnd();
        }
        
        if ($coaBankId) {
            $builder->groupStart()
                ->where('coa_id_debit', $coaBankId)
                ->orWhere('coa_id_kredit', $coaBankId)
                ->groupEnd();
        }
        
        // Ambil ID transaksi yang ditampilkan di halaman ini
        $offsetBuilder = clone $builder;
        $offsetBuilder->select('id')
            ->orderBy('tanggal', 'ASC')
            ->orderBy('id', 'ASC')
            ->limit($offset);
        
        $offsetIds = $offsetBuilder->get()->getResultArray();
        $excludeIds = array_column($offsetIds, 'id');
        
        if (!empty($excludeIds)) {
            $builder->whereNotIn('id', $excludeIds);
        }
        
        $result = $builder->get()->getRow();
        
        $totalMasuk = $result->total_masuk ?? 0;
        $totalKeluar = $result->total_keluar ?? 0;
        
        return $totalMasuk - $totalKeluar;
    }

    /**
     * Get mutasi bank by ID with details
     */
    public function getWithDetails($id)
    {
        $mutasi = $this->select('mutasi_bank.*, 
            creator.username as creator_name,
            coa_debit.kode_akun as kode_akun_debit,
            coa_debit.nama_akun as nama_akun_debit,
            coa_debit.tipe_akun as tipe_akun_debit,
            coa_kredit.kode_akun as kode_akun_kredit,
            coa_kredit.nama_akun as nama_akun_kredit,
            coa_kredit.tipe_akun as tipe_akun_kredit,
            jurnal.nomor_jurnal,
            jurnal.status as jurnal_status,
            spk.nomor_spk,
            spk.judul_pekerjaan')
            ->join('users as creator', 'creator.id = mutasi_bank.created_by', 'left')
            ->join('coa as coa_debit', 'coa_debit.id = mutasi_bank.coa_id_debit', 'left')
            ->join('coa as coa_kredit', 'coa_kredit.id = mutasi_bank.coa_id_kredit', 'left')
            ->join('jurnal', 'jurnal.id = mutasi_bank.jurnal_id', 'left')
            ->join('spk_instalasi as spk', 'spk.id = mutasi_bank.spk_id', 'left')
            ->where('mutasi_bank.id', $id)
            ->first();
        
        if (!$mutasi) {
            return null;
        }
        
        return $mutasi;
    }

    /**
     * Post mutasi bank (ubah status Draft → Posted) dan buat jurnal
     */
    public function postMutasi($id, $jurnalId)
    {
        $mutasi = $this->find($id);
        
        if (!$mutasi) {
            throw new \RuntimeException('Transaksi mutasi bank tidak ditemukan');
        }
        
        if ($mutasi['status'] !== 'Draft') {
            throw new \RuntimeException('Hanya transaksi dengan status Draft yang bisa diposting');
        }
        
        $data = [
            'id' => $id,
            'status' => 'Posted',
            'posted_at' => date('Y-m-d H:i:s'),
            'jurnal_id' => $jurnalId
        ];
        
        return $this->save($data);
    }

    /**
     * Batalkan mutasi bank (kembalikan ke Draft)
     */
    public function batalkanMutasi($id)
    {
        $mutasi = $this->find($id);
        
        if (!$mutasi) {
            throw new \RuntimeException('Transaksi mutasi bank tidak ditemukan');
        }
        
        if ($mutasi['status'] === 'Posted') {
            throw new \RuntimeException('Transaksi yang sudah diposting tidak dapat dibatalkan langsung. Batalkan jurnal terlebih dahulu.');
        }
        
        $data = [
            'id' => $id,
            'status' => 'Dibatalkan'
        ];
        
        return $this->save($data);
    }

    /**
     * Get daftar COA untuk dropdown
     * Memisahkan antara akun untuk transaksi masuk dan keluar
     */
    public function getCoaOptions($tipe = null, $isBank = true)
    {
        $coaModel = new \App\Models\CoaModel();
        
        $builder = $coaModel->where('is_header', 0)
                            ->where('is_active', 1);
        
        if ($isBank) {
            $builder->like('kode_akun', '1-11', 'after');
        }
        
        if ($tipe === 'Debit') {
            $builder->whereIn('tipe_akun', ['Beban', 'Aset']);
        } elseif ($tipe === 'Kredit') {
            $builder->whereIn('tipe_akun', ['Pendapatan', 'Kewajiban', 'Ekuitas']);
        }
        
        return $builder->orderBy('kode_akun', 'ASC')->findAll();
    }

    /**
     * Get ALL daftar COA untuk dropdown (tanpa filter tipe akun)
     */
    public function getAllCoaOptions($isBank = true)
    {
        $coaModel = new \App\Models\CoaModel();
        
        $builder = $coaModel->where('is_header', 0)
                            ->where('is_active', 1);
        
        if ($isBank) {
            $builder->like('kode_akun', '1-11', 'after');
        }
        
        return $builder->orderBy('kode_akun', 'ASC')->findAll();
    }

    /**
     * Get saldo bank terkini
     * DIPERBAIKI: Menghitung saldo berdasarkan COA bank yang benar
     */
    public function getSaldoBank($coaBankId = null, $tanggal = null)
    {
        if (!$coaBankId) {
            return 0;
        }
        
        $builder = $this->db->table('mutasi_bank')
            ->select("
                SUM(CASE WHEN coa_id_kredit = {$coaBankId} THEN jumlah ELSE 0 END) as total_masuk,
                SUM(CASE WHEN coa_id_debit = {$coaBankId} THEN jumlah ELSE 0 END) as total_keluar
            ")
            ->where('status', 'Posted');
        
        if ($tanggal) {
            $builder->where('tanggal <=', $tanggal);
        }
        
        $result = $builder->get()->getRow();
        
        if (!$result) {
            return 0;
        }
        
        return ($result->total_masuk ?? 0) - ($result->total_keluar ?? 0);
    }

    /**
     * Get ringkasan per bank
     * DIPERBAIKI: Menghitung per bank dengan benar
     */
    public function getRingkasanPerBank($tanggalMulai = null, $tanggalSelesai = null)
    {
        $bankAccounts = $this->db->table('coa')
            ->select('id, kode_akun, nama_akun')
            ->where('is_header', 0)
            ->where('is_active', 1)
            ->like('kode_akun', '1-11', 'after')
            ->get()
            ->getResultArray();
        
        $result = [];
        
        foreach ($bankAccounts as $bank) {
            $masukBuilder = $this->db->table('mutasi_bank')
                ->select('SUM(jumlah) as total_masuk')
                ->where('status', 'Posted')
                ->where('coa_id_kredit', $bank['id']);
            
            $keluarBuilder = $this->db->table('mutasi_bank')
                ->select('SUM(jumlah) as total_keluar')
                ->where('status', 'Posted')
                ->where('coa_id_debit', $bank['id']);
            
            if ($tanggalMulai) {
                $masukBuilder->where('tanggal >=', $tanggalMulai);
                $keluarBuilder->where('tanggal >=', $tanggalMulai);
            }
            
            if ($tanggalSelesai) {
                $masukBuilder->where('tanggal <=', $tanggalSelesai);
                $keluarBuilder->where('tanggal <=', $tanggalSelesai);
            }
            
            $totalMasuk = $masukBuilder->get()->getRow()->total_masuk ?? 0;
            $totalKeluar = $keluarBuilder->get()->getRow()->total_keluar ?? 0;
            
            if ($totalMasuk > 0 || $totalKeluar > 0) {
                $result[] = [
                    'kode_bank' => $bank['kode_akun'],
                    'nama_bank' => $bank['nama_akun'],
                    'total_masuk' => (float)$totalMasuk,
                    'total_keluar' => (float)$totalKeluar
                ];
            }
        }
        
        return $result;
    }

    /**
     * Get statistics
     * DIPERBAIKI: Menggunakan query builder yang benar
     */
    public function getStats($tanggalMulai = null, $tanggalSelesai = null)
    {
        $builder = $this->db->table('mutasi_bank')
            ->where('status', 'Posted');
        
        if ($tanggalMulai) {
            $builder->where('tanggal >=', $tanggalMulai);
        }
        
        if ($tanggalSelesai) {
            $builder->where('tanggal <=', $tanggalSelesai);
        }
        
        $result = $builder->select("
                COUNT(*) as total_transaksi,
                SUM(CASE WHEN tipe = 'Kredit' THEN jumlah ELSE 0 END) as total_masuk,
                SUM(CASE WHEN tipe = 'Debit' THEN jumlah ELSE 0 END) as total_keluar,
                COUNT(CASE WHEN tipe = 'Kredit' THEN 1 END) as jumlah_masuk,
                COUNT(CASE WHEN tipe = 'Debit' THEN 1 END) as jumlah_keluar,
                COUNT(CASE WHEN DATE(tanggal) = CURDATE() THEN 1 END) as transaksi_hari_ini
            ")
            ->get()
            ->getRow();
        
        if (!$result) {
            return [
                'total_transaksi' => 0,
                'total_masuk' => 0,
                'total_keluar' => 0,
                'jumlah_masuk' => 0,
                'jumlah_keluar' => 0,
                'transaksi_hari_ini' => 0
            ];
        }
        
        return (array)$result;
    }

    /**
     * Verifikasi saldo bank berdasarkan data di database
     * Untuk debugging
     */
    public function verifikasiSaldoBank($coaBankId = null, $tanggalAkhir = null)
    {
        if (!$coaBankId) {
            return ['error' => 'ID Bank tidak ditemukan'];
        }
        
        $builder = $this->db->table('mutasi_bank')
            ->select('id, tanggal, kode_transaksi, tipe, jumlah, coa_id_debit, coa_id_kredit')
            ->where('status', 'Posted')
            ->groupStart()
                ->where('coa_id_debit', $coaBankId)
                ->orWhere('coa_id_kredit', $coaBankId)
            ->groupEnd()
            ->orderBy('tanggal', 'ASC')
            ->orderBy('id', 'ASC');
        
        if ($tanggalAkhir) {
            $builder->where('tanggal <=', $tanggalAkhir);
        }
        
        $transaksi = $builder->get()->getResultArray();
        
        $saldo = 0;
        $detail = [];
        
        foreach ($transaksi as $trx) {
            if ($trx['coa_id_kredit'] == $coaBankId) {
                $saldo += $trx['jumlah'];
                $jenis = 'MASUK';
            } else {
                $saldo -= $trx['jumlah'];
                $jenis = 'KELUAR';
            }
            
            $detail[] = [
                'tanggal' => $trx['tanggal'],
                'kode' => $trx['kode_transaksi'],
                'jenis' => $jenis,
                'jumlah' => $trx['jumlah'],
                'saldo_kumulatif' => $saldo
            ];
        }
        
        return [
            'coa_bank_id' => $coaBankId,
            'saldo_akhir' => $saldo,
            'total_transaksi' => count($transaksi),
            'detail' => $detail
        ];
    }

    /**
     * Export data untuk Excel
     */
    public function getExportData($filters = [])
    {
        $builder = $this->select('mutasi_bank.*, 
            creator.username as creator_name,
            coa_debit.kode_akun as kode_akun_debit,
            coa_debit.nama_akun as nama_akun_debit,
            coa_kredit.kode_akun as kode_akun_kredit,
            coa_kredit.nama_akun as nama_akun_kredit,
            spk.nomor_spk,
            spk.judul_pekerjaan')
            ->join('users as creator', 'creator.id = mutasi_bank.created_by', 'left')
            ->join('coa as coa_debit', 'coa_debit.id = mutasi_bank.coa_id_debit', 'left')
            ->join('coa as coa_kredit', 'coa_kredit.id = mutasi_bank.coa_id_kredit', 'left')
            ->join('spk_instalasi as spk', 'spk.id = mutasi_bank.spk_id', 'left');
        
        if (!empty($filters['tanggal_mulai'])) {
            $builder->where('mutasi_bank.tanggal >=', $filters['tanggal_mulai']);
        }
        
        if (!empty($filters['tanggal_selesai'])) {
            $builder->where('mutasi_bank.tanggal <=', $filters['tanggal_selesai']);
        }
        
        if (!empty($filters['tipe'])) {
            $builder->where('mutasi_bank.tipe', $filters['tipe']);
        }
        
        if (!empty($filters['status'])) {
            $builder->where('mutasi_bank.status', $filters['status']);
        }
        
        $builder->orderBy('mutasi_bank.tanggal', 'DESC')
                ->orderBy('mutasi_bank.kode_transaksi', 'DESC');
        
        $mutasi = $builder->findAll();
        
        $exportData = [];
        foreach ($mutasi as $item) {
            $bank = '-';
            if ($item['tipe'] == 'Debit' && !empty(trim($item['bank_asal'] ?? ''))) {
                $bank = trim($item['bank_asal']);
            } elseif ($item['tipe'] == 'Kredit' && !empty(trim($item['bank_tujuan'] ?? ''))) {
                $bank = trim($item['bank_tujuan']);
            }
            
            $noReferensi = $item['no_referensi'] ?? '-';
            if (is_numeric($noReferensi) && strlen($noReferensi) > 10) {
                $noReferensi = "'" . $noReferensi;
            }
            
            $exportData[] = [
                'Kode Transaksi' => $item['kode_transaksi'],
                'Tanggal' => $item['tanggal'],
                'Tipe' => $item['tipe'],
                'Jumlah' => $item['jumlah'],
                'Keterangan' => $item['keterangan'],
                'Akun Debit' => ($item['kode_akun_debit'] ?? '') . ' - ' . ($item['nama_akun_debit'] ?? ''),
                'Akun Kredit' => ($item['kode_akun_kredit'] ?? '') . ' - ' . ($item['nama_akun_kredit'] ?? ''),
                'Bank' => $bank,
                'Bank Asal' => trim($item['bank_asal'] ?? '-'),
                'Bank Tujuan' => trim($item['bank_tujuan'] ?? '-'),
                'No Referensi' => $noReferensi,
                'Proyek' => ($item['nomor_spk'] ?? '') . ' - ' . ($item['judul_pekerjaan'] ?? ''),
                'Status' => $item['status'],
                'Dibuat Oleh' => $item['creator_name'] ?? '-',
                'Dibuat Tanggal' => $item['created_at']
            ];
        }
        
        return $exportData;
    }

    /**
     * Rekalkulasi saldo (untuk maintenance)
     */
    public function recalculateSaldo()
    {
        return true;
    }

    /**
     * Check if transaksi has been posted
     */
    public function isPosted($id)
    {
        $mutasi = $this->find($id);
        return $mutasi && $mutasi['status'] === 'Posted';
    }
}