<?php
namespace App\Models\Accounting;

use CodeIgniter\Model;
use App\Models\CoaModel;

class LabaRugiModel extends Model
{
    protected $table = 'jurnal';
    protected $primaryKey = 'id';
    protected $useAutoIncrement = true;
    protected $returnType = 'array';
    protected $useSoftDeletes = false;
    protected $protectFields = true;
    
    protected $useTimestamps = false;

    /**
     * Get total pendapatan untuk periode tertentu
     */
    public function getTotalPendapatan($tanggalMulai, $tanggalSelesai)
    {
        // Ambil akun pendapatan (tipe Pendapatan)
        $coaModel = new CoaModel();
        $akunPendapatan = $coaModel->where('tipe_akun', 'Pendapatan')
                                   ->where('is_active', 1)
                                   ->findAll();
        
        $akunIds = array_column($akunPendapatan, 'id');
        
        if (empty($akunIds)) {
            return 0;
        }
        
        // Ambil total kredit dari jurnal detail untuk akun pendapatan
        $builder = $this->db->table('jurnal_detail')
            ->select('SUM(jurnal_detail.kredit) as total')
            ->join('jurnal', 'jurnal.id = jurnal_detail.jurnal_id')
            ->where('jurnal.status', 'posted')
            ->where('jurnal.tanggal >=', $tanggalMulai)
            ->where('jurnal.tanggal <=', $tanggalSelesai)
            ->whereIn('jurnal_detail.coa_id', $akunIds);
        
        $result = $builder->get()->getRow();
        
        return $result->total ?? 0;
    }

    /**
     * Get total beban untuk periode tertentu
     */
    public function getTotalBeban($tanggalMulai, $tanggalSelesai)
    {
        // Ambil akun beban (tipe Beban)
        $coaModel = new CoaModel();
        $akunBeban = $coaModel->where('tipe_akun', 'Beban')
                              ->where('is_active', 1)
                              ->findAll();
        
        $akunIds = array_column($akunBeban, 'id');
        
        if (empty($akunIds)) {
            return 0;
        }
        
        // Ambil total debit dari jurnal detail untuk akun beban
        $builder = $this->db->table('jurnal_detail')
            ->select('SUM(jurnal_detail.debit) as total')
            ->join('jurnal', 'jurnal.id = jurnal_detail.jurnal_id')
            ->where('jurnal.status', 'posted')
            ->where('jurnal.tanggal >=', $tanggalMulai)
            ->where('jurnal.tanggal <=', $tanggalSelesai)
            ->whereIn('jurnal_detail.coa_id', $akunIds);
        
        $result = $builder->get()->getRow();
        
        return $result->total ?? 0;
    }

    /**
     * Get laba/rugi untuk periode tertentu
     */
    public function getLabaRugi($tanggalMulai, $tanggalSelesai)
    {
        $pendapatan = $this->getTotalPendapatan($tanggalMulai, $tanggalSelesai);
        $beban = $this->getTotalBeban($tanggalMulai, $tanggalSelesai);
        
        return [
            'pendapatan' => $pendapatan,
            'beban' => $beban,
            'laba_rugi' => $pendapatan - $beban,
            'is_laba' => ($pendapatan - $beban) > 0,
            'tanggal_mulai' => $tanggalMulai,
            'tanggal_selesai' => $tanggalSelesai
        ];
    }

    /**
     * Get detail pendapatan per akun
     */
    public function getDetailPendapatan($tanggalMulai, $tanggalSelesai)
    {
        $builder = $this->db->table('jurnal_detail')
            ->select('coa.id, coa.kode_akun, coa.nama_akun, coa.tipe_akun, SUM(jurnal_detail.kredit) as total')
            ->join('jurnal', 'jurnal.id = jurnal_detail.jurnal_id')
            ->join('coa', 'coa.id = jurnal_detail.coa_id')
            ->where('jurnal.status', 'posted')
            ->where('jurnal.tanggal >=', $tanggalMulai)
            ->where('jurnal.tanggal <=', $tanggalSelesai)
            ->where('coa.tipe_akun', 'Pendapatan')
            ->groupBy('coa.id, coa.kode_akun, coa.nama_akun, coa.tipe_akun')
            ->orderBy('coa.kode_akun', 'ASC');
        
        $result = $builder->get()->getResultArray();
        
        return $result;
    }

    /**
     * Get detail beban per akun
     */
    public function getDetailBeban($tanggalMulai, $tanggalSelesai)
    {
        $builder = $this->db->table('jurnal_detail')
            ->select('coa.id, coa.kode_akun, coa.nama_akun, coa.tipe_akun, SUM(jurnal_detail.debit) as total')
            ->join('jurnal', 'jurnal.id = jurnal_detail.jurnal_id')
            ->join('coa', 'coa.id = jurnal_detail.coa_id')
            ->where('jurnal.status', 'posted')
            ->where('jurnal.tanggal >=', $tanggalMulai)
            ->where('jurnal.tanggal <=', $tanggalSelesai)
            ->where('coa.tipe_akun', 'Beban')
            ->groupBy('coa.id, coa.kode_akun, coa.nama_akun, coa.tipe_akun')
            ->orderBy('coa.kode_akun', 'ASC');
        
        $result = $builder->get()->getResultArray();
        
        return $result;
    }

    /**
     * Get laba rugi per bulan dalam satu tahun
     */
    public function getLabaRugiPerBulan($tahun)
    {
        $results = [];
        
        for ($bulan = 1; $bulan <= 12; $bulan++) {
            $tanggalMulai = date('Y-m-d', strtotime("$tahun-$bulan-01"));
            $tanggalSelesai = date('Y-m-t', strtotime($tanggalMulai));
            
            $labaRugi = $this->getLabaRugi($tanggalMulai, $tanggalSelesai);
            $labaRugi['bulan'] = $bulan;
            $labaRugi['nama_bulan'] = $this->getNamaBulan($bulan);
            
            $results[] = $labaRugi;
        }
        
        return $results;
    }

    /**
     * Get laba rugi per tahun
     */
    public function getLabaRugiPerTahun($tahunMulai, $tahunSelesai = null)
    {
        if (!$tahunSelesai) {
            $tahunSelesai = $tahunMulai;
        }
        
        $results = [];
        
        for ($tahun = $tahunMulai; $tahun <= $tahunSelesai; $tahun++) {
            $tanggalMulai = date('Y-m-d', strtotime("$tahun-01-01"));
            $tanggalSelesai = date('Y-m-d', strtotime("$tahun-12-31"));
            
            $labaRugi = $this->getLabaRugi($tanggalMulai, $tanggalSelesai);
            $labaRugi['tahun'] = $tahun;
            
            $results[] = $labaRugi;
        }
        
        return $results;
    }

    /**
     * Get komparasi laba rugi (year over year)
     */
    public function getKomparasiLabaRugi($tahun1, $tahun2)
    {
        $labaRugi1 = $this->getLabaRugiPerTahun($tahun1);
        $labaRugi2 = $this->getLabaRugiPerTahun($tahun2);
        
        $data1 = $labaRugi1[0] ?? ['pendapatan' => 0, 'beban' => 0, 'laba_rugi' => 0];
        $data2 = $labaRugi2[0] ?? ['pendapatan' => 0, 'beban' => 0, 'laba_rugi' => 0];
        
        $growthPendapatan = $data1['pendapatan'] > 0 
            ? (($data2['pendapatan'] - $data1['pendapatan']) / $data1['pendapatan']) * 100 
            : 0;
        
        $growthLaba = $data1['laba_rugi'] > 0 
            ? (($data2['laba_rugi'] - $data1['laba_rugi']) / abs($data1['laba_rugi'])) * 100 
            : 0;
        
        return [
            'tahun1' => [
                'tahun' => $tahun1,
                'pendapatan' => $data1['pendapatan'],
                'beban' => $data1['beban'],
                'laba_rugi' => $data1['laba_rugi']
            ],
            'tahun2' => [
                'tahun' => $tahun2,
                'pendapatan' => $data2['pendapatan'],
                'beban' => $data2['beban'],
                'laba_rugi' => $data2['laba_rugi']
            ],
            'growth' => [
                'pendapatan' => $growthPendapatan,
                'laba_rugi' => $growthLaba
            ]
        ];
    }

    /**
     * Get margin laba
     */
    public function getMarginLaba($tanggalMulai, $tanggalSelesai)
    {
        $labaRugi = $this->getLabaRugi($tanggalMulai, $tanggalSelesai);
        
        $margin = 0;
        if ($labaRugi['pendapatan'] > 0) {
            $margin = ($labaRugi['laba_rugi'] / $labaRugi['pendapatan']) * 100;
        }
        
        return [
            'margin' => $margin,
            'pendapatan' => $labaRugi['pendapatan'],
            'laba_rugi' => $labaRugi['laba_rugi']
        ];
    }

    /**
     * Get nama bulan
     */
    private function getNamaBulan($bulan)
    {
        $bulanNames = [
            1 => 'Januari', 2 => 'Februari', 3 => 'Maret', 4 => 'April',
            5 => 'Mei', 6 => 'Juni', 7 => 'Juli', 8 => 'Agustus',
            9 => 'September', 10 => 'Oktober', 11 => 'November', 12 => 'Desember'
        ];
        
        return $bulanNames[$bulan] ?? '';
    }

    /**
     * Export data untuk Excel
     */
    public function getExportData($tanggalMulai, $tanggalSelesai)
    {
        $pendapatanDetail = $this->getDetailPendapatan($tanggalMulai, $tanggalSelesai);
        $bebanDetail = $this->getDetailBeban($tanggalMulai, $tanggalSelesai);
        $labaRugi = $this->getLabaRugi($tanggalMulai, $tanggalSelesai);
        
        $exportData = [
            'periode' => [
                'tanggal_mulai' => $tanggalMulai,
                'tanggal_selesai' => $tanggalSelesai
            ],
            'pendapatan' => $pendapatanDetail,
            'beban' => $bebanDetail,
            'total_pendapatan' => $labaRugi['pendapatan'],
            'total_beban' => $labaRugi['beban'],
            'laba_rugi' => $labaRugi['laba_rugi']
        ];
        
        return $exportData;
    }

    /**
     * Get ringkasan untuk dashboard
     */
    public function getDashboardSummary($tahun = null)
    {
        if (!$tahun) {
            $tahun = date('Y');
        }
        
        $tanggalMulai = date('Y-m-d', strtotime("$tahun-01-01"));
        $tanggalSelesai = date('Y-m-d', strtotime("$tahun-12-31"));
        
        $labaRugi = $this->getLabaRugi($tanggalMulai, $tanggalSelesai);
        $margin = $this->getMarginLaba($tanggalMulai, $tanggalSelesai);
        
        // Ambil laba rugi bulan berjalan
        $bulanIni = date('m');
        $tanggalMulaiBulan = date('Y-m-d', strtotime("$tahun-$bulanIni-01"));
        $tanggalSelesaiBulan = date('Y-m-t', strtotime($tanggalMulaiBulan));
        $labaRugiBulan = $this->getLabaRugi($tanggalMulaiBulan, $tanggalSelesaiBulan);
        
        return [
            'tahun' => $tahun,
            'pendapatan_tahun' => $labaRugi['pendapatan'],
            'beban_tahun' => $labaRugi['beban'],
            'laba_rugi_tahun' => $labaRugi['laba_rugi'],
            'margin_tahun' => $margin['margin'],
            'pendapatan_bulan' => $labaRugiBulan['pendapatan'],
            'beban_bulan' => $labaRugiBulan['beban'],
            'laba_rugi_bulan' => $labaRugiBulan['laba_rugi'],
            'nama_bulan' => $this->getNamaBulan((int)$bulanIni)
        ];
    }
}